package com.shashankgarag;

public class ShopCurrency {
    int EarthPoints;
}