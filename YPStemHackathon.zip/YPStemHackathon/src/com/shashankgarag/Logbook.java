package com.shashankgarag;

public class Logbook {
    String origin;
    String destination;
    String transport;

}
