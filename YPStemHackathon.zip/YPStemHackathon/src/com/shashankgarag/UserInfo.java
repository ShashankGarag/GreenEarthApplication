package com.shashankgarag;

public class UserInfo {
    String name;
    String email;
    String password;
    int age;

}
